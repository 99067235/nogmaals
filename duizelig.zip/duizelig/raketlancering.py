i = 30
while i > 0:
  print(i)
  i = i-1