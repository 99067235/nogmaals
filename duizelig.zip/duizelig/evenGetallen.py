i = 20
while i< 50:
    print (i)
    i = i+2