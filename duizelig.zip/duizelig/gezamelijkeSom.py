i = 50
while i <= 1000:
    print (i)
    i = i + 1